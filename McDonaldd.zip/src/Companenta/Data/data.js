import oybek from "../../Assets/Images/oybek abduljabborov.jpg"
import man from "../../Assets/Images/Muhammadxon.jpg"
import qobiljon from "../../Assets/Images/qobiljon rahmatullayev.jpg"
import kamil from "../../Assets/Images/kamil axmedov.jpg"
import mirfayzi from "../../Assets/Images/mirfayzi.jpg"
import faxriyor from  "../../Assets/Images/faxriyor.jpg"
import nozimjon from "../../Assets/Images/nozimjon.jpg"
import halimboy from "../../Assets/Images/abduhalim.jpg"




export const getData = async () => {
    return [
        {
            id: 1,
            fullname: "Oybek Abdulljabborov",
            fathername: ".............",
            age: 26,
            birthday: "07 02 1996",
            phone: "+998 (95) 027 04 96",
            img: oybek
        },
        {
            id: 2,
            fullname: "Muhammadxon Habibullaxonov",
            fathername: "Yusufxonovich",
            age: 15,
            birthday: "03 05 2022",
            phone: "+998 (99) 341 47 18",
            img: man,
        },
        {
            id: 3,
            fullname: "Qobiljon Rahmatullayev",
            fathername: "..............",
            age: 22,
            birthday: "24 05 2001",
            phone: "+998 (90) 050 03 25",
            img: qobiljon,
        },
        {
            id: 4,
            fullname: "Kamil Axmedov",
            fathername: "Nailovich",
            age: 20,
            birthday: "14 08 2003",
            phone: "+998 (93) 405 76 28",
            img: kamil,
        },
        {
            id: 5,
            fullname: "Mirfayzi Mirtursunov",
            fathername: "............",
            age: 13,
            birthday: "03 05 2009",
            phone: "+998 (90) 795 02 11",
            img: mirfayzi,
        },
        {
            id: 6,
            fullname: "Behruz Usmonov",
            fathername: "Sherzodoovich",
            age: 16,
            birthday: "31 07 2006",
            phone: "+998 (94) 152 49 89"
        },
        {
            id: 7,
            fullname: "Oybek Yusupjanov",
            fathername: "Rasuljonovich",
            age: 16,
            birthday: "27 12 2006",
            phone: "+998 (93) 108 51 06"
        },
        {
            id: 8,
            fullname: "Alyarov Faxriyor",
            fathername: "Farruxovich",
            age: 16,
            birthday: "24 05 2006",
            phone: "+998 (99) 695 20 85",
            img: faxriyor,
        },
        {
            id: 9,
            fullname: "Nozimjon Olimjonov",
            fathername: "................",
            age: 16,
            birthday: "12 08 2003",
            phone: "+998 (93) 268 47 40",
            img: nozimjon,
        },
        {
            id: 10,
            fullname: "Abduhalimboy Karimov",
            fathername: "Haliljonovich",
            age: 16,
            birthday: "03 07 2005",
            phone: "+998 (99) 396 51 77",
            img: halimboy,
        },
    ]
};