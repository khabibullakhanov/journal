import React from 'react';
import "./Home.css"
import { HeaderTable } from '../../Companenta/HeaderTable/HeaderTable'

export function Home() {
    return (
        <div>
            <HeaderTable/>
        </div>
    )
}
