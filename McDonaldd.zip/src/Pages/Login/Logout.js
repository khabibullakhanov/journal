import React from 'react'

export function Logout() {
    return (
        <div>
            <h1>Welcome <span>Muhammadxon</span></h1>
            <button>Log Out</button>
        </div>
    )
}
