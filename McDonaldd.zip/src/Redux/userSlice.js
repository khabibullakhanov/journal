// import { createSlice } from "@reduxjs/toolkit"

// export const userSlice = createSlice({
//     name: "user",

//     initialState: {
//         user: null,
//     },
//     reducers: {
//         updateUsername: (state, action) => {
//             state.value.map((user) => {
//               if (user.id === action.payload.id) {
//                 user.username = action.payload.username;
//               }
//             });
//           },
//     }

// export const { updateUsername } = userSlice.actions;
//     export default userSlice.reducer;